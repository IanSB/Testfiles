RGBtoHDMI

(c) 2018 David Banks (hoglet), Ian Bradbury (IanB), Dominic Plunkett (dp11) and Ed Spittles (BigEd)

TEST RELEASE 15/4/2019